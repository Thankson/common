#!/bin/bash
##############################
## Written by Deployer
## Date: 2017.07.15
## Info: check interval time
##
##############################

if [ $# != 1 ]; then
    echo "Usage: $0 <projectName>"
    echo "e.g. : $0 vst_pet"
    exit 1
fi

PRONAME="$1"

##restart count limit is CNTLIMIT
CNTLIMIT=1
RECNT='/tmp/recnt.txt'
[ ! -f "${RECNT}" ] && echo `date` >"${RECNT}"
CNT=`cat ${RECNT} |wc -l`

##check for interval seconds
diffSeconds=3600
 
############################# ADD New Rules #################################################
WEEKDAY=`date +%a` 
HOUR=`date +%H`

##Use for no work days
EXSECONDS=1200

if [ "$HOUR" -ge 8 -a "$HOUR" -lt 20 ]; then 
  if [ "$WEEKDAY" == 'Sat' -o "$WEEKDAY" == 'Sun' ];then 
   diffSeconds="${EXSECONDS}" 
    else 
   diffSeconds="${diffSeconds}" 
   fi
else
   diffSeconds="${EXSECONDS}" 
fi 
########################################################################################## 

chkIntervalTime(){
    nowTime=`date +%s`
    [ -z /tmp/restart_time_${PRONAME}.out -o ! -f /tmp/restart_time_${PRONAME}.out ] && {
        tomcatRunTime=0
    } || {
        tomcatRunTime=`cat /tmp/restart_time_${PRONAME}.out`
    }

    diffTime=`expr ${nowTime} - ${tomcatRunTime}`
    remainTime=`expr ${diffSeconds} - ${diffTime}`

    MINS=`expr ${remainTime} / 60`
    SEC=`expr ${remainTime} % 60`

    #echo ${diffTime}
    #echo ${diffSeconds}
    if [ "${diffTime}" -lt "${diffSeconds}" ];then
        [ "${CNT}" -ge "${CNTLIMIT}" ] && {
            #echo -e "\nI'm sorry, Please wait for ${MINS}m.${SEC}s and then restart Tomcat.\n"
            echo -e "\n\e[1;33mI'm sorry, Please wait for ${MINS}m.${SEC}s and then restart Tomcat.\e[0m\n"
            echo -e "\n>>>>>>> Warning!!! You cannot restart <${PRONAME}> <<<<<<<<" >/tmp/restart_result_${PRONAME}.out
            echo -e "I'm sorry, Please wait for ${MINS}m.${SEC}s and then restart Tomcat.\n" >>/tmp/restart_result_${PRONAME}.out
            echo `date` >>"${RECNT}"
            exit 100
        } || {
            let CNT+=1
            #echo -e "\nCongratulations, <${CNTLIMIT}-${CNT}> Restart <${PRONAME}> successed!!!\n" 
            echo -e "\n\e[1;32mCongratulations, <${CNTLIMIT}-${CNT}> Restart <${PRONAME}> successed!!!\e[0m\n"
            echo -e "\nCongratulations, <${CNTLIMIT}-${CNT}> Restart <${PRONAME}> successed!!!" >/tmp/restart_result_${PRONAME}.out
            echo `date` >>"${RECNT}"
        }
    else     
        #echo -e "\nCongratulations, <${CNTLIMIT}-1> Restart <${PRONAME}> successed!!!\n" 
        echo -e "\n\e[1;32mCongratulations, <${CNTLIMIT}-${CNT}> Restart <${PRONAME}> successed!!!\e[0m\n"
        echo -e "\nCongratulations, <${CNTLIMIT}-1> Restart <${PRONAME}> successed!!!" >/tmp/restart_result_${PRONAME}.out
        echo `date` >"${RECNT}"
    fi
}

##Invote function.
chkIntervalTime

##clear log time
echo `date +%s` >/tmp/restart_time_${PRONAME}.out
