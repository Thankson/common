#!/bin/bash

if [ $# != 1 ]; then
    echo "Usage: $0 <projectName>"
    echo "e.g. : $0 vst_pet"
    exit 0
fi

PRONAME="$1"

OPTSDATA="-vzrtopgl --delete --exclude .svn --exclude staticHtml --exclude classes --progress --password-file=/etc/rsyncd.passwd"
rsync $OPTSDATA lvmama_web@10.200.4.100::TRUNK/$PRONAME/ /var/www/webapps/$PRONAME/

OPTSCONFIG="-vzrtopgl --delete --exclude .svn --exclude . --progress --password-file=/etc/rsyncd.passwd"
rsync $OPTSCONFIG lvmama_web@10.200.4.100::FZ_CONFIGS/$PRONAME/ /var/www/webapps/$PRONAME/WEB-INF/classes/
