#!/usr/bin/python
#coding:utf-8
######################################
## Write by Deployer
## Write Date: 2016.02.29
## Modify: 2016.05.13
## Add multi_project xml
## 2017.06.07 use for restart tomcat
##
######################################

try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET

import os,sys,re
import socket
import fcntl
import struct


if len(sys.argv) < 2:
    print "\nUsage: python %s DIR" % sys.argv[0]
    print "e.g. : python %s /opt\n" % sys.argv[0]
    sys.exit()

tomcat_path = sys.argv[1].rstrip('/')

def getIPAddress(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915,  # SIOCGIFADDR
        struct.pack('256s', ifname[:15])
    )[20:24])

#read dir filename
def listdirFun(path,conf):
    xmlfile = []
    lists = os.listdir(path)
    pattern = re.compile("apache-tomcat-[-a-z]*")
    for line in lists:
        if pattern.match(line):
            #print line
            str = '/'
            seq = (path,line,conf)
            filepath = str.join(seq)
            #print filepath

            if os.path.isfile(filepath):
                xmlfile.append(filepath)
    return xmlfile


#read xml file func
def showxmlFunc(filename,outfile):
    pro_info = []
    fo = open(outfile, 'a')

    try:
        tree = ET.parse(filename)
        root = tree.getroot()
    except Exception, e:
        print "Error: Cannot parse file: server.xml."
        sys.exit(1)
    
    p = re.compile('^\d{4}')
    IP = getIPAddress('eth0')
    
    for service in root.findall('Service'):
        #print service.attrib
        for connector in service.findall('Connector'):
            #print connector.attrib
            #port = connector.get('port')
                if p.findall(connector.get('port')):
                    port = connector.get('port')
                #print 'Port -->',port
        for engine in service.findall('Engine'):
                #print engine.attrib
                for host in engine.findall('Host'):
                    #print host.attrib
                    for context in host.findall('Context'):
                        #print context.attrib

                        #displayname = context.get('displayName')
                        #print "displayName -->",displayname

                        docbase = context.get('docBase')
                        #print "docBase -->",docbase
                        pro_info.append(docbase.split('/')[-1])

                        path = context.get('path')
                        #print "Path -->",path
                        fo.write('http://'+IP+':'+port+path+'/'+'checkversion.jsp'+'\n')
    fo.close()
    return ' '.join(pro_info)

if __name__ == '__main__':

    conf_path = 'conf/server.xml'
    outfile = '/opt/shells/tomcatUrlInfo.txt'

    if os.path.exists(outfile):
        os.remove(outfile)
    
    for line in listdirFun(tomcat_path,conf_path):
        #print 'Tomcat Project ->',line
        tomcat_dir = line.split('/')[2]
        project = showxmlFunc(line,outfile)

        print '%s %s' % (tomcat_dir,project)

    #print getIPAddress('eth0')
