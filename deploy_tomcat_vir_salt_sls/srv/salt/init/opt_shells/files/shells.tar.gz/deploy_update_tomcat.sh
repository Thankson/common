#!/bin/bash
#############################
## Write by Deployer
## Date: 2017.06.08
## Info: Lvmama DeployGroup
##
#############################

##input project name or paramenter
input_name=$1

##Only for restart tomcat
tomcatRestart(){
    TOMCATDIR=$1
    pid=`pgrep -f /opt/${TOMCATDIR}/bin`
    times=0
    tomcat_path="/opt/${TOMCATDIR}"
    ${tomcat_path}/bin/shutdown.sh
    while true
        do 
            if [ -z ${pid} ]; then
                echo -e '\n\n\n\n'
                echo -e "\033[35m      Are you ready? Deploying and Restarting Tomcat!!!      \033[0m";
                echo -e '\n\n\n\n'
                break
            else
                sleep 1
                echo ${times}
                let times++
            fi
            if [ ${times} -eq 10 -o ${times} -eq 14 ]; then
                kill -9 ${pid} >/dev/null 2>&1
                sleep 2
                break
            fi
    done
    ${tomcat_path}/bin/startup.sh &
}

##Create project list file
[ ! -d /opt/shells ] && mkdir -p /opt/shells
PROJECTINFO='/opt/shells/projectInfo.txt'
/usr/bin/python /opt/shells/generate_tomcat_info.py '/opt' >${PROJECTINFO}
[ -f "${PROJECTINFO}" ] && {
    sed -i '/generate_tomcat_info.*/d' "${PROJECTINFO}"
    sed -i '/^$/d' "${PROJECTINFO}"
    PROCNT=`cat ${PROJECTINFO} |wc -l`
}

##Show available project name
showProject(){
   [ -f "${PROJECTINFO}" ] && {
       echo -e '\n'
       echo -e "\n\033[32m### Available Porject Name ###\033[0m"
       while read DIR PRO; do
           echo -e "\033[32m${PRO}\033[0m"
       done <${PROJECTINFO}
       echo -e "\033[32m###############################\033[0m\n"
       echo -e '\n\n\n'
   }

}

##Update all tomcat data file and restart tomcat
if [ "${input_name}" == 'ALL' ]; then
    while read line; do
       CNT=`echo "$line" |wc -w`
       i=1
       while [ "$i" -lt "$CNT" ]; do
           INDEX=`expr $i + 1`
           DIR=`echo $line |awk '{print $1}'`
           PRO=`echo $line |cut -d ' ' -f ${INDEX}`

           ##Check interval time of limit.
           /bin/sh /opt/shells/interval_time_limit.sh ${PRO}
           [ $? != 0 ] && exit 0
           ##Update new data files...
           /bin/sh /opt/shells/fz_update_datafiles.sh ${PRO}
           let i++
       done
       ##Restart tomcat
       tomcatRestart ${DIR}
   done <${PROJECTINFO}

##input one parameter of project name
elif [ "${input_name}" != '' ]; then
    ##Tomcat count greater than 1
    [ "${PROCNT}" -gt 1 ] && {
        flag=0
        while read line; do
            CNT=`echo "$line" |wc -w`
            i=1
            while [ "$i" -lt "$CNT" ]; do
                INDEX=`expr $i + 1`
                ##DIR=`echo $line |awk '{print $1}'`
                PRO=`echo $line |cut -d ' ' -f ${INDEX}`

                [ "${input_name}" == "${PRO}" ] && {
                    let flag++
                }
                let i++
            done
        done <${PROJECTINFO}
        
        [ "${flag}" -ge 1 ] && {
            line=`cat ${PROJECTINFO} |grep -E "\b${input_name}\b"`
            CNT=`echo "$line" |wc -w`
            i=1
            while [ "$i" -lt "$CNT" ]; do
                INDEX=`expr $i + 1`
                DIR=`echo $line |awk '{print $1}'`
                PRO=`echo $line |cut -d ' ' -f ${INDEX}`

                ##Check interval time of limit.
                /bin/sh /opt/shells/interval_time_limit.sh ${PRO}
                [ $? != 0 ] && exit 0
                ##Update new data files...
                /bin/sh /opt/shells/fz_update_datafiles.sh ${PRO}
                let i++
            done

            ##Restart tomcat
            tomcatRestart ${DIR}
        } || {
            echo -e "\n\e[1;33mYour input <${input_name}> is not exist.\e[0m"
            showProject
        }

    ##Tomcat count equals 1
    } || {
        grep -E "\b${input_name}\b" ${PROJECTINFO} >/dev/null 2>&1
        [ $? = 0 ] && {
            line=`cat ${PROJECTINFO} |grep -E "\b${input_name}\b"`
            CNT=`echo "$line" |wc -w`
            i=1
            while [ "$i" -lt "$CNT" ]; do
                INDEX=`expr $i + 1`
                DIR=`echo $line |awk '{print $1}'`
                PRO=`echo $line |cut -d ' ' -f ${INDEX}`

                ##Check interval time of limit.
                /bin/sh /opt/shells/interval_time_limit.sh ${PRO}
                [ $? != 0 ] && exit 0
                ##Update new data files...
                /bin/sh /opt/shells/fz_update_datafiles.sh ${PRO}
                let i++
            done

            ##Restart tomcat
            tomcatRestart ${DIR}
        } || {
            echo -e "\n\e[1;33mYour input <${input_name}> is not exist.\e[0m"
            showProject
        }
    }

##Do not input any project name
elif [ "${input_name}" = '' ]; then
   ##Tomcat count equals 1
   [ "${PROCNT}" = 1 ] && {
       line=`cat ${PROJECTINFO} |grep -E "\b${input_name}\b"`
       CNT=`echo "$line" |wc -w`
       i=1
       while [ "$i" -lt "$CNT" ]; do
           INDEX=`expr $i + 1`
           DIR=`echo $line |awk '{print $1}'`
           PRO=`echo $line |cut -d ' ' -f ${INDEX}`

           ##Check interval time of limit.
           /bin/sh /opt/shells/interval_time_limit.sh ${PRO}
           [ $? != 0 ] && exit 0
           ##Update new data files...
           /bin/sh /opt/shells/fz_update_datafiles.sh ${PRO}
           let i++
       done

       ##Restart tomcat
       tomcatRestart ${DIR}
   ##TOmcat count greater than 1 and show available project name
   } || {
       echo -e "\n\e[1;33mYou did not input any project name.\e[0m" 
       showProject
   }
else
    echo -e '\nNever here.'
fi
