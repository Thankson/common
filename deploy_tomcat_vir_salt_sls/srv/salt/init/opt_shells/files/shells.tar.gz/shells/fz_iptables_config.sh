#!/bin/bash

RELEASE=`awk '{print $(NF-1)}' /etc/redhat-release`

rules(){

iptables --flush
iptables -A INPUT -i eth0 -s 10.111.1.0/24 -j ACCEPT
iptables -A INPUT -i eth0 -s 10.200.0.0/16 -j ACCEPT
iptables -A INPUT -i eth0 -s 10.201.0.0/16 -j ACCEPT
iptables -A INPUT -i eth0 -s 192.168.0.0/24 -j ACCEPT
iptables -A INPUT -i eth0 -s 10.112.4.71 -j ACCEPT
iptables -A INPUT -i eth0 -s 10.112.4.73 -j ACCEPT
iptables -A INPUT -i eth0 -s 10.113.10.124 -j ACCEPT
iptables -A INPUT -i eth0 -s 10.113.10.123 -j ACCEPT
iptables -A INPUT -i eth0 -s 10.113.9.0/24 -j ACCEPT
iptables -A INPUT -i eth0 -s 10.112.0.0/16 -p tcp --dport 22 -j ACCEPT
iptables -A INPUT -i eth0 -s 10.0.0.0/8 -j DROP
service iptables save

}

startip(){

systemctl stop firewalld.service
systemctl disable firewalld.service
systemctl enable iptables
systemctl start iptables

}

if [[ $RELEASE =~ ^7 ]]&&[[ `rpm -q iptables-services>/dev/null;echo $?` != 0 ]];then

	yum install iptables-services -y
		
fi

if [[ $RELEASE =~ ^7 ]];then
	startip
	rules
else
	service iptables start
	rules
fi
